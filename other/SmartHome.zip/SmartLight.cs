public class SmartLight : SmartDevice
{
    public SmartLight(string name) : base(name)
    {
        
    }
}